/* ===== EDIT YOUR DETAILS HERE ===== */
const CONFIG = {
  email: "your-email@example.com", // <-- replace with your real email
  roles: [
    "Computer Science student",
    "Mechanical design engineer",
    "Problem solver",
    "Future software developer"
  ],
  facts: [
    { title: "B.Tech, Computer Science", note: "Synergy Institute of Technology" },
    { title: "Diploma, Mechanical", note: "Indus School of Engineering" },
    { title: "Certified designer", note: "Skill Development India" },
    { title: "Based in", note: "Bhubaneswar, Odisha" }
  ],
  education: [
    {
      title: "B.Tech in Computer Science",
      where: "Synergy Institute of Technology, Pahala, Bhubaneswar",
      when: "Currently pursuing",
      text: "Studying programming, data structures, databases and web development."
    },
    {
      title: "Certificate in Mechanical Designing Engineering",
      where: "Skill Development India",
      when: "Completed",
      text: "Hands-on training in mechanical design and engineering drawing."
    },
    {
      title: "Diploma in Mechanical Engineering",
      where: "Indus School of Engineering, Khurda",
      when: "Completed",
      text: "Built the base in mechanics, manufacturing processes and technical drawing."
    }
  ],
  skills: {
    Software: [
      ["HTML", 85], ["CSS", 80], ["JavaScript", 70], ["C / C++", 65], ["Python", 60], ["Git and GitHub", 60]
    ],
    Mechanical: [
      ["Engineering drawing", 85], ["CAD modelling", 75], ["Machine design basics", 75], ["Manufacturing processes", 70]
    ],
    "Soft skills": [
      ["Problem solving", 85], ["Teamwork", 80], ["Quick learning", 85], ["Communication", 75]
    ]
  },
  projects: [
    { kind: "Software", title: "This portfolio website", text: "A responsive, themeable portfolio built with plain HTML, CSS and JavaScript.", tags: ["HTML", "CSS", "JavaScript"] },
    { kind: "Software", title: "Your software project", text: "Replace this with a project you built: what it does and what you learned.", tags: ["Add", "your", "tools"] },
    { kind: "Mechanical", title: "Your mechanical design", text: "Replace this with a part or assembly you modelled, and the problem it solves.", tags: ["CAD", "Design"] },
    { kind: "Mechanical", title: "Your diploma project", text: "Describe your diploma project work here, with your role and the outcome.", tags: ["Diploma", "Mechanical"] }
  ]
};

/* ===== Helpers ===== */
const $ = (id) => document.getElementById(id);
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function makeTabs(container, labels, onSelect) {
  container.innerHTML = "";
  labels.forEach((label, i) => {
    const b = document.createElement("button");
    b.className = "tab";
    b.type = "button";
    b.setAttribute("role", "tab");
    b.textContent = label;
    b.setAttribute("aria-selected", i === 0);
    b.addEventListener("click", () => {
      container.querySelectorAll(".tab").forEach((t) => t.setAttribute("aria-selected", t === b));
      onSelect(label);
    });
    container.appendChild(b);
  });
  onSelect(labels[0]);
}

/* ===== About facts and education ===== */
$("facts").innerHTML = CONFIG.facts
  .map((f) => `<li><b>${f.title}</b><span>${f.note}</span></li>`).join("");

$("timeline").innerHTML = CONFIG.education
  .map((e) => `<li><h3>${e.title}</h3><div class="where">${e.where}</div><div class="when">${e.when}</div><p>${e.text}</p></li>`)
  .join("");

/* ===== Skills ===== */
function showSkills(group) {
  $("skillList").innerHTML = CONFIG.skills[group]
    .map(([name, pct]) => `<div class="skill"><div class="row"><span>${name}</span><span>${pct}%</span></div><div class="bar"><i data-w="${pct}"></i></div></div>`)
    .join("");
  requestAnimationFrame(() => requestAnimationFrame(() => {
    document.querySelectorAll(".bar i").forEach((el) => (el.style.width = el.dataset.w + "%"));
  }));
}
makeTabs($("skillTabs"), Object.keys(CONFIG.skills), showSkills);

/* ===== Projects ===== */
function showProjects(filter) {
  const list = filter === "All" ? CONFIG.projects : CONFIG.projects.filter((p) => p.kind === filter);
  $("projectGrid").innerHTML = list
    .map((p) => `<article class="project"><span class="kind">${p.kind}</span><h3>${p.title}</h3><p>${p.text}</p><div class="tags">${p.tags.map((t) => `<span>${t}</span>`).join("")}</div></article>`)
    .join("");
}
makeTabs($("projectTabs"), ["All", "Software", "Mechanical"], showProjects);

/* ===== Typing effect ===== */
(function typing() {
  const el = $("typed");
  if (reduceMotion) { el.textContent = CONFIG.roles[0]; return; }
  let r = 0, c = 0, deleting = false;
  function tick() {
    const word = CONFIG.roles[r];
    c += deleting ? -1 : 1;
    el.textContent = word.slice(0, c);
    let delay = deleting ? 40 : 90;
    if (!deleting && c === word.length) { deleting = true; delay = 1500; }
    else if (deleting && c === 0) { deleting = false; r = (r + 1) % CONFIG.roles.length; delay = 400; }
    setTimeout(tick, delay);
  }
  tick();
})();

/* ===== Meshing gears (the one animated moment) ===== */
(function gears() {
  const svg = $("gears");
  const NS = "http://www.w3.org/2000/svg";

  function gearPath(teeth, rOut, rRoot) {
    const step = (Math.PI * 2) / teeth;
    const pts = [];
    for (let i = 0; i < teeth; i++) {
      const a = i * step;
      [[0.05, rRoot], [0.2, rOut], [0.5, rOut], [0.65, rRoot]].forEach(([f, r]) => {
        const ang = a + f * step;
        pts.push((Math.cos(ang) * r).toFixed(1) + "," + (Math.sin(ang) * r).toFixed(1));
      });
    }
    return "M" + pts.join("L") + "Z";
  }

  const big = { teeth: 24, out: 130, root: 112, pitch: 121 };
  const small = { teeth: 12, out: 70, root: 52, pitch: 60.5 };
  const bx = 170, by = 215;
  const dist = big.pitch + small.pitch;
  const sx = bx + dist * Math.cos(-0.62);
  const sy = by + dist * Math.sin(-0.62);

  function build(g, cx, cy) {
    const grp = document.createElementNS(NS, "g");
    const path = document.createElementNS(NS, "path");
    path.setAttribute("d", gearPath(g.teeth, g.out, g.root));
    const hub = document.createElementNS(NS, "circle");
    hub.setAttribute("r", g.root * 0.3);
    const hole = document.createElementNS(NS, "circle");
    hole.setAttribute("r", g.root * 0.1);
    grp.append(path, hub, hole);
    svg.appendChild(grp);
    return (deg) => grp.setAttribute("transform", `translate(${cx} ${cy}) rotate(${deg})`);
  }

  const setBig = build(big, bx, by);
  const setSmall = build(small, sx, sy);
  const meshOffset = 180 / small.teeth + Math.atan2(sy - by, sx - bx) * (180 / Math.PI) * (big.teeth / small.teeth + 1);

  function draw(angle) {
    setBig(angle);
    setSmall(-angle * (big.teeth / small.teeth) + meshOffset);
  }

  let start = performance.now();
  function frame(now) {
    const spin = reduceMotion ? 0 : (now - start) / 1000 * 6;
    draw(spin + window.scrollY * 0.12);
    requestAnimationFrame(frame);
  }
  draw(0);
  requestAnimationFrame(frame);
})();

/* ===== Theme toggle (remembers choice when storage is available) ===== */
(function theme() {
  const root = document.documentElement;
  const btn = $("themeToggle");
  let saved = null;
  try { saved = localStorage.getItem("theme"); } catch (e) {}
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  apply(saved || (prefersDark ? "dark" : "light"));

  function apply(mode) {
    root.setAttribute("data-theme", mode);
    btn.textContent = mode === "dark" ? "Light mode" : "Dark mode";
  }
  btn.addEventListener("click", () => {
    const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    apply(next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });
})();

/* ===== Contact form: validates, then opens the visitor's email app ===== */
$("sendBtn").addEventListener("click", () => {
  const name = $("cName").value.trim();
  const email = $("cEmail").value.trim();
  const msg = $("cMsg").value.trim();
  const note = $("formNote");
  note.className = "note";

  if (!name || !msg) { note.textContent = "Enter your name and a message."; note.classList.add("error"); return; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { note.textContent = "Enter a valid email address."; note.classList.add("error"); return; }

  const subject = encodeURIComponent("Portfolio message from " + name);
  const body = encodeURIComponent(msg + "\n\nFrom: " + name + " (" + email + ")");
  window.location.href = `mailto:${CONFIG.email}?subject=${subject}&body=${body}`;
  note.textContent = "Opening your email app. Send the message there to finish.";
  note.classList.add("ok");
});

$("year").textContent = new Date().getFullYear();
